﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => "Server=LAPTOP-B774MQCB;Database=BookShop;Integrated Security=True;";
    }
}
