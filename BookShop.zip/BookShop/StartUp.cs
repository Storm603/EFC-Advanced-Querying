﻿using System;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using BookShop.Models.Enums;

namespace BookShop
{
    using BookShop.Models;
    using Data;
    using Initializer;
    using Microsoft.EntityFrameworkCore;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            //DbInitializer.ResetDatabase(db);

            Console.WriteLine(GetBooksByCategory(db, Console.ReadLine()));
            
            

        }

        public static string GetBooksByCategory(BookShopContext db, string category)
        {
            string[] bookCategoriesSearchedBy = category.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray();

            string[] bookTitles = db.Books.Where(e => e.BookCategories.Any(cat => bookCategoriesSearchedBy.Contains(cat.Category.Name))).OrderBy(e => e.Title).Select(e => e.Title).ToArray();

            StringBuilder sb = new StringBuilder();

            foreach (var item in bookTitles)
            {
                sb.AppendLine(item);
            }

            return sb.ToString().Trim();
        }

        //public static string GetBooksNotReleasedIn(BookShopContext db, int year)
        //{
        //    StringBuilder sb = new StringBuilder();

        //    string[] ctx = db.Books.Where(e => e.ReleaseDate.Value.Year != year).OrderBy(e => e.BookId).Select(e => e.Title).ToArray();

        //    foreach (var item in ctx)
        //    {
        //        sb.AppendLine(item);
        //    }

        //    return sb.ToString().Trim();
        //}

        //public static string GetBooksByPrice(BookShopContext db)
        //{
        //    StringBuilder sb = new StringBuilder();

        //    var sdasd = db.Books.Where(e => e.Price > 40).Select(e => new
        //    {
        //        e.Title,
        //        e.Price
        //    }).OrderByDescending(e => e.Price).ToArray();

        //    foreach (var item in sdasd)
        //    {
        //        sb.AppendLine($"{item.Title} - ${item.Price}");
        //    }

        //    return sb.ToString().Trim();
        //}

        //public static string GetGoldenBooks(BookShopContext db)
        //{
        //    StringBuilder sb = new StringBuilder();

        //    string[] bookNames = db.Books.Where(e => e.EditionType == (EditionType) 2 && e.Copies < 5000).OrderBy(e => e.BookId)
        //        .Select(e => e.Title).ToArray();

        //    foreach (string bookName in bookNames)
        //    {
        //        sb.AppendLine(bookName);
        //    }

        //    return sb.ToString().Trim();
        //}


        //public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        //{
        //    StringBuilder sb = new StringBuilder();

        //    AgeRestriction res;

        //    string[] bookNames = context.Books.Where(b => b.AgeRestriction == Enum.Parse<AgeRestriction>(command, true)).OrderBy(e => e.Title)
        //        .Select(e => e.Title).ToArray();

        //    foreach (string bookName in bookNames)
        //    {
        //        sb.AppendLine(bookName);
        //    }

        //    return sb.ToString().Trim();
        //}
    }
}
